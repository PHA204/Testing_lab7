package dtm.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class CheckoutPage {

    WebDriver driver;

    @FindBy(id = "first-name")
    WebElement firstName;

    @FindBy(id = "last-name")
    WebElement lastName;

    @FindBy(id = "postal-code")
    WebElement zip;

    @FindBy(id = "continue")
    WebElement continueBtn;

    @FindBy(className = "summary_subtotal_label")
    WebElement itemTotal;

    @FindBy(className = "summary_tax_label")
    WebElement tax;

    @FindBy(className = "summary_total_label")
    WebElement total;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void fillInfo(String f, String l, String z) {
        firstName.sendKeys(f);
        lastName.sendKeys(l);
        zip.sendKeys(z);
        continueBtn.click();
    }

    public double getItemTotal() {
        return Double.parseDouble(itemTotal.getText().replaceAll("[^0-9.]", ""));
    }

    public double getTax() {
        return Double.parseDouble(tax.getText().replaceAll("[^0-9.]", ""));
    }

    public double getTotal() {
        return Double.parseDouble(total.getText().replaceAll("[^0-9.]", ""));
    }
}