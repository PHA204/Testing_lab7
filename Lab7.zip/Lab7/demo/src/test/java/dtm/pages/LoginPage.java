package dtm.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class LoginPage {

    WebDriver driver;

    @FindBy(id = "user-name")
    WebElement username;

    @FindBy(id = "password")
    WebElement password;

    @FindBy(id = "login-button")
    WebElement loginBtn;

    @FindBy(css = "div[data-test='error']")
    WebElement errorMsg;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void login(String user, String pass) {
        username.clear();
        username.sendKeys(user);
        password.clear();
        password.sendKeys(pass);
        loginBtn.click();
    }

    public boolean isSuccess() {
        return driver.getCurrentUrl().contains("inventory");
    }

    public String getError() {
        try {
            return errorMsg.getText();
        } catch (Exception e) {
            return null;
        }
    }
}