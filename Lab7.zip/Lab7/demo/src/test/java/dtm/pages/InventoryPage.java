package dtm.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import java.util.*;

public class InventoryPage {

    WebDriver driver;

    @FindBy(className = "inventory_item")
    List<WebElement> items;

    @FindBy(className = "shopping_cart_badge")
    WebElement badge;

    @FindBy(className = "shopping_cart_link")
    WebElement cartLink;

    public InventoryPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void addNProducts(int n) {
        for (int i = 0; i < n; i++) {
            items.get(i).findElement(By.tagName("button")).click();
        }
    }

    public int getBadgeCount() {
        try {
            return Integer.parseInt(badge.getText());
        } catch (Exception e) {
            return 0;
        }
    }

    public void goToCart() {
        cartLink.click();
    }
}