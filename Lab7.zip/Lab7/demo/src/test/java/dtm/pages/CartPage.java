package dtm.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import java.util.*;

public class CartPage {

    WebDriver driver;

    @FindBy(className = "cart_item")
    List<WebElement> cartItems;

    @FindBy(id = "checkout")
    WebElement checkoutBtn;

    public CartPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public int getCartItemCount() {
        return cartItems.size();
    }

    public void clickCheckout() {
        checkoutBtn.click();
    }
}