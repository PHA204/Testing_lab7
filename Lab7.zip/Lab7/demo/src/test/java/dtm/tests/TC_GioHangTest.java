package dtm.tests;

import dtm.base.BaseTest;
import dtm.pages.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_GioHangTest extends BaseTest {

    @Test(groups={"regression"})
    public void them3SanPham() {

        LoginPage login = new LoginPage(getDriver());
        login.login("standard_user", "secret_sauce");

        InventoryPage inventory = new InventoryPage(getDriver());
        inventory.addNProducts(3);

        Assert.assertEquals(inventory.getBadgeCount(), 3);
    }
}