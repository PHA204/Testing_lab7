package dtm.tests;

import dtm.base.BaseTest;
import dtm.pages.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_CheckoutTest extends BaseTest {

    @Test(groups={"regression"})
    public void kiemTraTongTien() {

        LoginPage login = new LoginPage(getDriver());
        login.login("standard_user", "secret_sauce");

        InventoryPage inventory = new InventoryPage(getDriver());
        inventory.addNProducts(2);
        inventory.goToCart();

        CartPage cart = new CartPage(getDriver());
        cart.clickCheckout();

        CheckoutPage checkout = new CheckoutPage(getDriver());
        checkout.fillInfo("A", "B", "700000");

        double itemTotal = checkout.getItemTotal();
        double tax = checkout.getTax();
        double total = checkout.getTotal();

        Assert.assertTrue(Math.abs(tax - itemTotal * 0.08) < 0.01);
        Assert.assertTrue(Math.abs(total - (itemTotal + tax)) < 0.01);
    }
}