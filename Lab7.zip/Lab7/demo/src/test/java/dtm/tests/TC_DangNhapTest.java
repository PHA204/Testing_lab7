package dtm.tests;

import dtm.base.BaseTest;
import dtm.data.DangNhapData;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_DangNhapTest extends BaseTest {

    @Test(dataProvider = "du_lieu_dang_nhap",
          dataProviderClass = DangNhapData.class,
          groups = {"smoke"})
    public void testLogin(String user, String pass, String expected) {

        LoginPage login = new LoginPage(getDriver());
        login.login(user, pass);

        switch (expected) {

            case "SUCCESS":
                Assert.assertTrue(login.isSuccess());
                break;

            case "LOCKED":
                Assert.assertTrue(login.getError().contains("locked out"));
                break;

            case "FAIL":
            case "EMPTY":
                Assert.assertNotNull(login.getError());
                break;
        }
    }
}