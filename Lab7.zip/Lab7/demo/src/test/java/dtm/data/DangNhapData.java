package dtm.data;

import org.testng.annotations.DataProvider;

public class DangNhapData {

    @DataProvider(name = "du_lieu_dang_nhap")
    public Object[][] getData() {
        return new Object[][]{

                {"standard_user", "secret_sauce", "SUCCESS"},
                {"locked_out_user", "secret_sauce", "LOCKED"},
                {"abc", "123", "FAIL"},
                {"", "secret_sauce", "EMPTY"},
                {"standard_user", "", "EMPTY"},
                {"", "", "EMPTY"}
        };
    }
}